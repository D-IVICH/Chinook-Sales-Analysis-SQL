# Business Findings — Chinook Digital Music Store

> **Completion note:** This document is structured around the queries in `chinook_analysis.sql`. The uploaded SQL script does not contain the executed result tables, so the bracketed fields below must be filled from the actual query outputs before publishing. No figures have been invented.

## 1. Executive summary
This project examines sales performance and customer purchasing patterns in the Chinook Digital Music Store database using PostgreSQL. The analysis covers overall revenue, country-level performance, customer spending, track/genre/artist revenue, monthly trends, units sold, and revenue rankings.

**Key results to add after checking the outputs:**
- Total revenue: **[enter result and currency/unit]**
- Number of invoices: **[enter result]**
- Average invoice value: **[enter result and currency/unit]**
- Highest-revenue country: **[enter country and revenue]**
- Highest-spending customer: **[enter customer and spend]**
- Highest-revenue track: **[enter track and revenue]**
- Highest-revenue genre: **[enter genre and revenue]**
- Highest-revenue artist: **[enter artist and revenue]**
- Highest-revenue month: **[enter month and revenue]**
- Most-purchased track by units: **[enter track and units]**

## 2. Database familiarization and relationships
The SQL analysis lists the tables in the `public` schema and counts records in the `Customer`, `Invoice`, and `InvoiceLine` tables.

The script identifies these relationships:
- `Customer` to `Invoice`: one-to-many through `CustomerId`.
- `Invoice` to `InvoiceLine`: one-to-many through `InvoiceId`.
- `Track` to `InvoiceLine`: linked through `TrackId`.
- `Artist` to `Album`: linked through `ArtistId`.
- `Album` to `Track`: linked through `AlbumId`.
- `Genre` to `Track`: linked through `GenreId`.

These relationships allow invoice and invoice-line data to be connected to customers and music products for analysis.

**Record counts:** Customer = **[enter count]**; Invoice = **[enter count]**; InvoiceLine = **[enter count]**.

## 3. Overall sales performance
The analysis calculates revenue from invoice-line items as `UnitPrice × Quantity`. It also calculates total invoice revenue, invoice count, and average invoice value from the `Invoice` table.

- Invoice-line revenue: **[enter result]**
- Sum of invoice totals: **[enter result]**
- Invoice count: **[enter result]**
- Average invoice value: **[enter result]**

**Interpretation:** Compare invoice-line revenue with the sum of invoice totals. If they differ, investigate the discrepancy before publishing the final conclusion. The two calculations use different tables and should not automatically be assumed to be identical.

## 4. Revenue by country
The country analysis joins `Customer` to `Invoice`, groups invoices by customer country, and sorts countries from highest to lowest revenue. A second query returns the top five countries.

**Top five countries by revenue:**
1. **[Country]** — **[Revenue]**
2. **[Country]** — **[Revenue]**
3. **[Country]** — **[Revenue]**
4. **[Country]** — **[Revenue]**
5. **[Country]** — **[Revenue]**

**Business implication:** Use the actual ranking to identify the strongest revenue-generating markets. Revenue alone does not explain why a country performs well; customer count and average spend would be useful follow-up measures.

## 5. Customer purchasing analysis
The query aggregates invoice totals by customer and returns the five customers with the highest total spending.

**Top five customers by total spend:**
1. **[Customer name / ID]** — **[Spend]**
2. **[Customer name / ID]** — **[Spend]**
3. **[Customer name / ID]** — **[Spend]**
4. **[Customer name / ID]** — **[Spend]**
5. **[Customer name / ID]** — **[Spend]**

**Business implication:** The ranking can help identify high-value customers for retention and targeted engagement. The output shows historical spending, not necessarily future customer value.

## 6. Track performance by revenue
The analysis joins `Track` and `InvoiceLine`, calculates each track's revenue as `UnitPrice × Quantity`, and returns the ten highest-revenue tracks.

**Top tracks by revenue:** **[Insert the ten tracks and their revenue from the query output.]**

**Business implication:** High-revenue tracks may merit visibility in recommendations or promotions. Revenue ranking is different from unit-sales ranking, so both measures should be considered.

## 7. Revenue by genre
The query connects `Genre`, `Track`, and `InvoiceLine`, then aggregates revenue by genre.

- Highest-revenue genre: **[Genre]**
- Revenue: **[Amount]**
- Next strongest genres: **[Add genres from the output]**

**Business implication:** The results can inform genre-focused promotion and catalogue decisions. Confirm that the conclusion reflects revenue, not simply the number of tracks available in each genre.

## 8. Revenue by artist
The query joins `Artist`, `Album`, `Track`, and `InvoiceLine` to calculate revenue by artist. A separate query returns the top ten artists.

- Highest-revenue artist: **[Artist]**
- Revenue: **[Amount]**
- Top ten artists: **[Insert ranking from the query output]**

**Business implication:** Artist-level revenue can highlight commercially strong parts of the catalogue. It does not, by itself, measure profit because costs are not included.

## 9. Monthly sales performance
The monthly analysis groups invoice totals by month and reports invoice count and monthly revenue. Separate queries identify the highest- and lowest-revenue months.

- Highest-revenue month: **[Month]** — **[Revenue]**
- Lowest-revenue month: **[Month]** — **[Revenue]**
- Trend across the period: **[Describe what the monthly results show]**

**Business implication:** Monthly trends can help with sales monitoring and campaign planning. Avoid describing a month as seasonal based on one occurrence; multiple years of comparable monthly data would be needed to support a seasonality claim.

## 10. Best-selling tracks by quantity
The query sums `InvoiceLine.Quantity` for each track and returns the ten tracks with the highest units sold.

**Top ten tracks by units sold:** **[Insert tracks and unit counts from the query output.]**

**Business implication:** This list highlights purchase volume. Compare it with the revenue ranking to see whether the most frequently purchased tracks are also the highest earners.

## 11. Revenue ranking
The final query uses `RANK()` to rank tracks according to total revenue and returns the top ten rows.

**Top ten ranked tracks:** **[Insert track, revenue, and rank from the output.]**

**Interpretation:** `RANK()` gives equal ranks to tracks with tied revenue, and the next rank can be skipped after a tie. Because the query applies `LIMIT 10`, the output is limited to ten rows; ties at the cutoff may mean it does not show every track tied for tenth place.

## 12. Recommendations
Complete these recommendations only after entering the actual findings:
1. Focus retention efforts on the highest-spending customers identified in Task 4.
2. Review the leading countries and assess whether their performance reflects more customers, higher average spend, or both.
3. Consider targeted promotion for high-revenue genres, artists, and tracks.
4. Compare revenue rankings with unit-sales rankings to distinguish high-value products from high-volume products.
5. Monitor monthly revenue and invoice counts together to understand whether changes reflect transaction volume or average invoice value.

## 13. Limitations
- This analysis describes recorded sales; it does not include operating costs, profit margins, marketing costs, or customer acquisition costs.
- Rankings reflect the records available in the database and may not generalize to other periods or music businesses.
- The SQL file alone does not provide executed output values. All bracketed fields must be completed from the user's actual query results before this document is presented as a final findings report.
