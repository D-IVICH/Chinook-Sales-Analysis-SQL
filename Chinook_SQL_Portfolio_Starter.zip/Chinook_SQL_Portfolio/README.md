# Chinook Digital Music Store — SQL Business Analysis

## Project overview
This project uses SQL to analyze sales and customer activity in the Chinook Digital Music Store database. The analysis is written in PostgreSQL and covers database familiarization, table relationships, revenue, customer spending, track and genre performance, artist revenue, monthly sales, units sold, and revenue ranking.

## Business questions
1. What tables are available, and how many customer, invoice, and invoice-line records are present?
2. How are customers, invoices, invoice lines, tracks, genres, albums, and artists connected?
3. What is the store's total revenue, invoice count, and average invoice value?
4. Which countries generate the most revenue?
5. Which customers spend the most?
6. Which tracks generate the highest revenue?
7. Which genres and artists generate the most revenue?
8. How does revenue change month by month, and which months have the highest and lowest revenue?
9. Which tracks sell the most units?
10. How do tracks rank by revenue?

## Tools and techniques
- PostgreSQL
- SQL joins (`INNER JOIN`)
- Aggregation (`SUM`, `COUNT`, `AVG`)
- Grouping and sorting (`GROUP BY`, `ORDER BY`)
- Filtering result sets (`LIMIT`)
- Date transformation (`DATE_TRUNC`, `TO_CHAR`)
- Window functions (`RANK`)

## Repository contents
- `chinook_analysis.sql` — SQL table definitions and analysis queries.
- `business_findings.md` — business interpretation template to complete using the actual query outputs.

## How to run
1. Create or open a PostgreSQL database for the Chinook dataset.
2. Load the source data into the tables expected by the script. The supplied SQL file includes table definitions and analysis queries; check whether your database already contains the data before running the table-creation section.
3. Open `chinook_analysis.sql` in pgAdmin or another PostgreSQL client.
4. Run the queries by task and save/export the result sets needed for `business_findings.md`.

## Important note
The supplied `.sql` file contains queries and table definitions, but it does not include the result tables produced when the queries were executed. Therefore, numerical findings should be entered only after checking the saved query outputs. Do not treat placeholder fields in `business_findings.md` as real results.

## Suggested GitHub project description
SQL analysis of the Chinook Digital Music Store database, exploring revenue, customer spending, track and genre performance, artist sales, monthly trends, and product rankings using PostgreSQL.
